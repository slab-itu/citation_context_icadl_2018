# -*- coding: utf-8 -*-
"""
Created on Mon Jun 11 12:22:39 2018

@author: Trend Lab
"""

import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D

df = pd.read_csv("best_features.csv")
x = np.array(df.iloc[:,2:31])
y = np.array(df.iloc[:,31:32])

x = StandardScaler().fit_transform(x)
pca = PCA(n_components=28,svd_solver='arpack')
principalComponents = pca.fit_transform(x)
principalDf = pd.DataFrame(data = principalComponents
             , columns = ['principal component 1', 'principal component 2'
                          ,'principal component 3','principal component 4'
                          ,'principal component 5',
                          'p6','p7','p8','p9',
                          'p10','p11','p12','p13',
                          'p14','p15','p16','p17',
                          'p18','p19','p20','p21',
                          
                          'p22','p23','p24','p25',
                          'p26','p27','p28'])

finalDf = pd.concat([principalDf, df[['2-Class']]], axis = 1)

fig = plt.figure()
#ax = fig.add_subplot(111,projection='3d') 
ax = fig.add_subplot(1,1,1)
#ax.plot(x, y)
ax.spines['left'].set_position('center')
ax.spines['right'].set_color('none')
ax.spines['bottom'].set_position('center')
ax.spines['top'].set_color('none')
ax.spines['left'].set_smart_bounds(True)
ax.spines['bottom'].set_smart_bounds(True)
ax.xaxis.set_ticks_position('bottom')
ax.yaxis.set_ticks_position('left')


#ax.set_xlabel('Principal Component 1', fontsize = 15)
#ax.set_ylabel('Principal Component 2', fontsize = 15)
#ax.set_zlabel('Principal Component 2', fontsize = 15)
#ax.set_title('3 component PCA', fontsize = 20)
targets = [0, 1]
colors = ['r', 'g']
for target, color in zip(targets,colors):
    print(target)
    indicesToKeep = finalDf['2-Class'] == target
    '''ax.scatter(finalDf.loc[indicesToKeep, 'principal component 3']
               , finalDf.loc[indicesToKeep, 'principal component 2']
               , finalDf.loc[indicesToKeep, 'principal component 1']
               , c = color
               , s = 50)'''
    ax.scatter(finalDf.loc[indicesToKeep, 'principal component 1']
               , finalDf.loc[indicesToKeep, 'principal component 2']
               , c = color
               , s = 50)
    
ax.legend(['Incidental Cittaions','Important Citations'])
ax.grid()
fig.savefig('temp.png', dpi=1000)

print(pca.explained_variance_ratio_)
print(pca.singular_values_)  