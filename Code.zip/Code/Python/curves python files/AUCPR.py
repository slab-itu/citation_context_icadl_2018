# -*- coding: utf-8 -*-
"""
Created on Sun Aug 06 22:21:57 2017

@author: Asma
"""
# -*- coding: utf-8 -*-
"""
Created on Sun Jun 12 14:03:32 2016


"""
import numpy
from scipy import interp
import matplotlib.pyplot as plt
import pandas as pd
from sklearn import svm
from sklearn.metrics import auc
from sklearn.cross_validation import StratifiedKFold
from sklearn.metrics import precision_recall_curve
from sklearn.metrics import average_precision_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_selection import SelectFromModel
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB


# import some data to play with
mydata = pd.read_csv("C:/Users/Asma/Desktop/FINAL_TABLE_USER2 - Copy - Copy.csv")
y = mydata["TOP_25_PAPERS"]  #provided your csv has header row, and the label column is named "Label"
n_points=len(mydata)
##select all but the last column as data
X = mydata.ix[:,:-1]
#X=X.iloc[:,:]

##################################


cv = StratifiedKFold(y, n_folds=10)


y_real1 = []
y_proba1 = []

y_real2 = []
y_proba2 = []

y_real3 = []
y_proba3 = []

y_real4 = []
y_proba4 = []

y_real5 = []
y_proba5 = []

y_real6 = []
y_proba6 = []

y_real7 = []
y_proba7 = []

y_real8 = []
y_proba8 = []

y_real9 = []
y_proba9 = []

y_real10 = []
y_proba10 = []

y_real11 = []
y_proba11 = []



#classifier = svm.SVC(kernel='rbf',gamma=0.001, C=100, probability=True, class_weight ='balanced')
classifier = RandomForestClassifier(n_estimators=100,
                                 class_weight="auto",
                                 criterion='gini',
                                 bootstrap=True,
                                 max_features=0.5,
                                 min_samples_split=1,
                                 min_samples_leaf=5,
                                 max_depth=10,
                                 n_jobs=1)

#classifier= KNeighborsClassifier()
#classifier = GaussianNB()
#classifier = DecisionTreeClassifier(max_depth=15)

for i, (train, test) in enumerate(cv):
    x_train=X[train[0]:train[len(train)-1]]
    x_test=X[test[0]:test[len(test)-1]]
    y_train= y[train[0]:train[len(train)-1]]
    y_test=y[test[0]:test[len(test)-1]]      
             
    probas1_ = classifier.fit(x_train.iloc[:,0].reshape(-1,1), y_train).predict_proba( x_test.iloc[:,0].reshape(-1,1))
    probas2_ = classifier.fit(x_train.iloc[:,1].reshape(-1,1), y_train).predict_proba( x_test.iloc[:,1].reshape(-1,1))
    probas3_ = classifier.fit(x_train.iloc[:,2].reshape(-1,1), y_train).predict_proba( x_test.iloc[:,2].reshape(-1,1))
    probas4_ = classifier.fit(x_train.iloc[:,3].reshape(-1,1), y_train).predict_proba( x_test.iloc[:,3].reshape(-1,1))
    probas5_ = classifier.fit(x_train.iloc[:,4].reshape(-1,1), y_train).predict_proba( x_test.iloc[:,4].reshape(-1,1))
    probas6_ = classifier.fit(x_train.iloc[:,5].reshape(-1,1), y_train).predict_proba( x_test.iloc[:,5].reshape(-1,1))
    probas7_ = classifier.fit(x_train.iloc[:,6].reshape(-1,1), y_train).predict_proba( x_test.iloc[:,6].reshape(-1,1))
    probas8_ = classifier.fit(x_train.iloc[:,7].reshape(-1,1), y_train).predict_proba( x_test.iloc[:,7].reshape(-1,1))
    probas9_ = classifier.fit(x_train.iloc[:,8].reshape(-1,1), y_train).predict_proba( x_test.iloc[:,8].reshape(-1,1))
    probas10_ = classifier.fit(x_train.iloc[:,9].reshape(-1,1), y_train).predict_proba( x_test.iloc[:,9].reshape(-1,1))
    probas11_ = classifier.fit(x_train.iloc[:,10].reshape(-1,1), y_train).predict_proba( x_test.iloc[:,10].reshape(-1,1))
    
    
    y_real1.append(y_test)
    y_proba1.append(probas1_[:, 1])
    
    y_real2.append(y_test)
    y_proba2.append(probas2_[:, 1])
    
    y_real3.append(y_test)
    y_proba3.append(probas3_[:, 1])
    
    y_real4.append(y_test)
    y_proba4.append(probas4_[:, 1])
        
    y_real5.append(y_test)
    y_proba5.append(probas5_[:, 1])
    
    y_real6.append(y_test)
    y_proba6.append(probas6_[:, 1])
    
    y_real7.append(y_test)
    y_proba7.append(probas7_[:, 1])
    
    y_real8.append(y_test)
    y_proba8.append(probas8_[:, 1])
    
    y_real9.append(y_test)
    y_proba9.append(probas9_[:, 1])
    
    y_real10.append(y_test)
    y_proba10.append(probas10_[:, 1])
        
    y_real11.append(y_test)
    y_proba11.append(probas11_[:, 1])
    
y_real1 = numpy.concatenate(y_real1)
y_proba1 = numpy.concatenate(y_proba1)

y_real2 = numpy.concatenate(y_real2)
y_proba2 = numpy.concatenate(y_proba2)

y_real3 = numpy.concatenate(y_real3)
y_proba3 = numpy.concatenate(y_proba3)

y_real4 = numpy.concatenate(y_real4)
y_proba4 = numpy.concatenate(y_proba4)

y_real5 = numpy.concatenate(y_real5)
y_proba5 = numpy.concatenate(y_proba5)

y_real6 = numpy.concatenate(y_real6)
y_proba6 = numpy.concatenate(y_proba6)

y_real7 = numpy.concatenate(y_real7)
y_proba7 = numpy.concatenate(y_proba7)

y_real8 = numpy.concatenate(y_real8)
y_proba8 = numpy.concatenate(y_proba8)

y_real9 = numpy.concatenate(y_real9)
y_proba9 = numpy.concatenate(y_proba9)

y_real10 = numpy.concatenate(y_real10)
y_proba10 = numpy.concatenate(y_proba10)

y_real11 = numpy.concatenate(y_real11)
y_proba11 = numpy.concatenate(y_proba11)

precision1, recall1, _ = precision_recall_curve(y_real1, y_proba1)
precision2, recall2, _ = precision_recall_curve(y_real2, y_proba2)
precision3, recall3, _ = precision_recall_curve(y_real3, y_proba3)
precision4, recall4, _ = precision_recall_curve(y_real4, y_proba4)
precision5, recall5, _ = precision_recall_curve(y_real5, y_proba5)
precision6, recall6, _ = precision_recall_curve(y_real6, y_proba6)
precision7, recall7, _ = precision_recall_curve(y_real7, y_proba7)
precision8, recall8, _ = precision_recall_curve(y_real8, y_proba8)
precision9, recall9, _ = precision_recall_curve(y_real9, y_proba9)
precision10, recall10, _ = precision_recall_curve(y_real10, y_proba10)
precision11, recall11, _ = precision_recall_curve(y_real11, y_proba11)

lab = 'F1(area = %0.2f)' % (auc(recall1, precision1))
lab2 = 'F2(area = %0.2f)' % (auc(recall2, precision2))
lab3 = 'F3(area = %0.2f)' % (auc(recall3, precision3))
lab4 = 'F4(area = %0.2f)' % (auc(recall4, precision4))
lab5 = 'F5(area = %0.2f)' % (auc(recall5, precision5))
lab6 = 'F6(area = %0.2f)' % (auc(recall6, precision6))
lab7 = 'F7(area = %0.2f)' % (auc(recall7, precision7))
lab8 = 'F8(area = %0.2f)' % (auc(recall8, precision8))
lab9 = 'F9(area = %0.2f)' % (auc(recall9, precision9))
lab10 = 'F10(area = %0.2f)' % (auc(recall10, precision10))
lab11 = 'F11(area = %0.2f)' % (auc(recall11, precision11))

plt.plot(recall1, precision1, label=lab, lw=2, color='red') 
plt.plot(recall2, precision2, label=lab2, lw=2, color='green') 
plt.plot(recall3, precision3, label=lab3, lw=2, color='blue') 
plt.plot(recall4, precision4, label=lab4, lw=2, color='purple') 
plt.plot(recall5, precision5, label=lab5, lw=2, color='mediumseagreen')
plt.plot(recall6, precision6, label=lab6, lw=2, color='aqua') 
plt.plot(recall7, precision7, label=lab7, lw=2, color='indigo') 
plt.plot(recall8, precision8, label=lab8, lw=2, color='navy') 
plt.plot(recall9, precision9, label=lab9, lw=2, color='midnightblue') 
plt.plot(recall10, precision10, label=lab10, lw=2, color='sienna') 
plt.plot(recall11, precision11, label=lab11, lw=2, color='lime') 

















plt.xlim([0.02, 0.99])
plt.ylim([0, 1.05])
plt.grid(True)
plt.xlabel('Recall')
plt.ylabel('Precision')
plt.title('Precision Recall curve, Individual Features using Random Forest')
plt.rcParams['axes.facecolor']='white'
plt.legend(loc="lower left")
plt.show()


    
    
    
