# -*- coding: utf-8 -*-
"""
Created on Sun Jun 12 14:03:32 2016

@author: anam
"""
import numpy as np
from scipy import interp
import matplotlib.pyplot as plt
import pandas as pd
from sklearn import svm, datasets
from sklearn.metrics import roc_curve, auc
from sklearn.cross_validation import StratifiedKFold
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.feature_selection import SelectFromModel
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.naive_bayes import GaussianNB
###############################################################################


file = 'our_model.csv'
print(file)
mydata = pd.read_csv("data/"+file)
# import some data 
#mydata = pd.read_csv("C:/Users/Asma/Desktop/FINAL_TABLE_USER2 - Copy - Copy.csv")
y = mydata["Class"]  #provided your csv has header row, and the label column is named "Label")
##select all but the last column as data
X = mydata.ix[:,:-1]
X=X.iloc[:,:]

############################################################
## Build a forest and compute the feature importances
#forest = ExtraTreesClassifier(n_estimators=100,
#                              random_state=0)
#
#forest.fit(X1, y)
#
#model = SelectFromModel(forest, prefit=True)
#X = model.transform(X1)

######################

# Classification and ROC analysis
# Run SVM/Random forest classifier with cross-validation and plot ROC curves

cv = StratifiedKFold(y, n_folds=10)

classifier1 = svm.SVC(kernel='rbf',gamma=0.001, C=10, probability=True, class_weight ='balanced')

classifier2 = RandomForestClassifier(n_estimators=50,
                                  class_weight="auto",
                                  criterion='gini',
                                  bootstrap=True,
                                  max_features=0.5,
                                  min_samples_split=1,
                                  min_samples_leaf=10,
                                  max_depth=10,
                                  n_jobs=1)


classifier3= KNeighborsClassifier()
classifier4 = GaussianNB()
classifier5 = DecisionTreeClassifier(max_depth=5)
################  ROC analysis

mean_tpr1 = 0.0
mean_fpr1 = np.linspace(0, 1, 100)

mean_tpr2 = 0.0
mean_fpr2 = np.linspace(0, 1, 100)

mean_tpr3 = 0.0
mean_fpr3 = np.linspace(0, 1, 100)

mean_tpr4 = 0.0
mean_fpr4 = np.linspace(0, 1, 100)

mean_tpr5 = 0.0
mean_fpr5 = np.linspace(0, 1, 100)

all_tpr = []

for i, (train, test) in enumerate(cv):
    x_train=X[train[0]:train[len(train)-1]]
    x_test=X[test[0]:test[len(test)-1]]
    y_train= y[train[0]:train[len(train)-1]]
    y_test=y[test[0]:test[len(test)-1]]
    
    probas1_ = classifier1.fit(x_train, y_train).predict_proba( x_test)
    probas2_ = classifier2.fit(x_train, y_train).predict_proba( x_test)
    probas3_ = classifier3.fit(x_train, y_train).predict_proba( x_test)
    probas4_ = classifier4.fit(x_train, y_train).predict_proba( x_test)
    probas5_ = classifier5.fit(x_train, y_train).predict_proba( x_test) 
    
    
    fpr2, tpr2, thresholds2 = roc_curve(y_test, probas2_[:, 1])
    mean_tpr2 += interp(mean_fpr2, fpr2, tpr2)
    mean_tpr2[0] = 0.0

    fpr3, tpr3, thresholds3 = roc_curve(y_test, probas3_[:, 1])
    mean_tpr3 += interp(mean_fpr3, fpr3, tpr3)
    mean_tpr3[0] = 0.0

    fpr4, tpr4, thresholds4 = roc_curve(y_test, probas4_[:, 1])
    mean_tpr4 += interp(mean_fpr4, fpr4, tpr4)
    mean_tpr4[0] = 0.0

    fpr5, tpr5, thresholds5 = roc_curve(y_test, probas5_[:, 1])
    mean_tpr5 += interp(mean_fpr5, fpr5, tpr5)
    mean_tpr5[0] = 0.0

    fpr1, tpr1, thresholds1 = roc_curve(y_test, probas1_[:, 1])
    mean_tpr1 += interp(mean_fpr1, fpr1, tpr1)
    mean_tpr1[0] = 0.0


plt.plot([0, 1], [0, 1], color=(0.6, 0.6, 0.6))

mean_tpr1 /= len(cv)
mean_tpr1[-1] = 1.0
mean_auc1 = auc(mean_fpr1, mean_tpr1)

mean_tpr2 /= len(cv)
mean_tpr2[-1] = 1.0
mean_auc2 = auc(mean_fpr2, mean_tpr2)

mean_tpr3 /= len(cv)
mean_tpr3[-1] = 1.0
mean_auc3 = auc(mean_fpr3, mean_tpr3)

mean_tpr4 /= len(cv)
mean_tpr4[-1] = 1.0
mean_auc4 = auc(mean_fpr4, mean_tpr4)

mean_tpr5 /= len(cv)
mean_tpr5[-1] = 1.0
mean_auc5 = auc(mean_fpr5, mean_tpr5)



plt.plot(mean_fpr1, mean_tpr1, label='Mean ROC SVM (area = %0.2f)' % mean_auc1, lw=1,color="blue")
plt.plot(mean_fpr2, mean_tpr2, label='Mean ROC Random Forest (area = %0.2f)' % mean_auc2, lw=1,color="green")
plt.plot(mean_fpr3, mean_tpr3, label='Mean ROC KNN (area = %0.2f)' % mean_auc3, lw=1,color="brown")
plt.plot(mean_fpr4, mean_tpr4, label='Mean ROC Naive Bayes(area = %0.2f)' % mean_auc4, lw=1,color="purple")
plt.plot(mean_fpr4, mean_tpr5, label='Mean ROC Decision Tree(area = %0.2f)' % mean_auc5, lw=1,color="aqua")





plt.xlim([-0.02, 1.0])
plt.ylim([-0.02, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver operating characteristic')
plt.legend(loc="lower right")
plt.show()