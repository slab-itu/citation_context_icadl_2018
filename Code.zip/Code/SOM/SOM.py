# -*- coding: utf-8 -*-
"""
Created on Thu Jun 28 14:00:22 2018

@author: Trend Lab
"""
import pandas as pd
from numpy import genfromtxt,array,linalg,zeros,apply_along_axis
import numpy as np
from matplotlib import pyplot as plt
from matplotlib import patches as patches
import matplotlib.lines as mlines
from minisom import MiniSom
import csv


df = pd.read_csv("E:/Serish/paper2/PCA/best_features.csv")
patterns = np.array(df.iloc[:,2:31])
classes = np.array(df.iloc[:,32:33])

som = MiniSom(10,10,29,sigma=1.0,learning_rate=0.5)
som.random_weights_init(patterns)
print("Training...")
som.train_random(patterns,100) # training with 100 iterations
print("\n...ready!")

from pylab import plot,axis,show,pcolor,colorbar,bone
bone()
pcolor(som.distance_map().T) # distance map as background
colorbar()
# loading the labels
target = genfromtxt("E:/Serish/paper2/PCA/best_features.csv",
                    delimiter=',',usecols=(32),dtype=str)
t = zeros(len(target),dtype=int)
t[target == '0'] = 0
t[target == '1'] = 1
# use different colors and markers for each label
markers = ['o','s','D']
colors = ['r','g']
aa = np.zeros((10, 10))
bb = np.zeros((10, 10))
cc = np.zeros((10, 10))
for cnt,xx in enumerate(patterns):
 w = som.winner(xx)
 aa[9-w[1]][w[0]]=aa[9-w[1]][w[0]]+1
 if(colors[t[cnt]]=='r') :
     bb[9-w[1]][w[0]]=bb[9-w[1]][w[0]]+1
 else:
     cc[9-w[1]][w[0]]=cc[9-w[1]][w[0]]+1
     # getting the winner
 # palce a marker on the winning position for the sample xx
 plot(w[0]+.5,w[1]+.5,markers[t[cnt]],markerfacecolor='None',
   markeredgecolor=colors[t[cnt]],markersize=12,markeredgewidth=2)
axis([0,10,0,10])
plt.savefig('E:/Serish/paper2/PCA/SOM.png', dpi=1000)
show() # show the figure

np.savetxt("non_imp.csv", bb, delimiter=",")
np.savetxt("imp.csv", cc, delimiter=",")
